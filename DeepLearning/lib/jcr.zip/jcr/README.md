# Joe's C Resources (JCR) #

I keep pulling in random boilerplate C from various old projects so I'm gonna consolidate them in one place.

If you use this library your code will crash and burn and fail miserably don't do it this is your one warning.
